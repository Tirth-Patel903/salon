export class Services {
    constructor(

        public id?: number,
        public name?: string,
        public price?: number,
        public time?: number,
        public point?: number,
        public isactive?: boolean,
        public createddate?: Date,
        public updateddate?: Date,
        public index?: number
    ) {
    }
}