export class Loginuser {
    constructor(

        public email?: any,
        public password?: any,
        public role?: any,
        public adminrole?: any
    ) {
    }
}