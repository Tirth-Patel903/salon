// /* SystemJS module definition */
// declare var : {
//   id: string;
// };
